﻿using FinanzplanerApp.Views;

namespace FinanzplanerApp
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute("LoginPage", typeof(LoginPage));
            Routing.RegisterRoute("RegistrationPage", typeof(Views.RegistrationPage));
        }
    }
}
