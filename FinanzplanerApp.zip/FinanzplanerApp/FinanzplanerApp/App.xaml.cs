﻿using FinanzplanerApp.Views;

namespace FinanzplanerApp
{
    public partial class App : Application
    {
        public App()
        {
            MainPage = new NavigationPage(new LoginPage());
        }
    }
}
