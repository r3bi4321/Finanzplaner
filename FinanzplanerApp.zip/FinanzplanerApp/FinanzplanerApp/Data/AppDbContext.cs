﻿using Microsoft.EntityFrameworkCore;
using FinanzplanerApp.Models;

namespace FinanzplanerApp.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Account> Accounts { get; set; }
        public DbSet<TransactionEntry> Transactions { get; set; }
        public DbSet<User> Users { get; set; }  // Neu: Benutzer

      
        private const string ConnectionString =
          "Server=HP-ST444\\SQLEXPRESS;Database=FinanzplanerDB;Trusted_Connection=True;TrustServerCertificate=True;";


        // Oder Windows-Authentifizierung:
        // 
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Hier legen wir fest, dass wir SQL Server verwenden
                optionsBuilder.UseSqlServer(ConnectionString);
            }
        }
    }
}
