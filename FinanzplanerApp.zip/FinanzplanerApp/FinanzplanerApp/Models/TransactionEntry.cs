﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinanzplanerApp.Models
{
    public class TransactionEntry
    {
        public int Id { get; set; }            // Primärschlüssel
        public int AccountId { get; set; }     // Fremdschlüssel zu Account
        public decimal Amount { get; set; }    // + = Einnahme, - = Ausgabe
        public DateTime Date { get; set; }
        public string Category { get; set; }   // Benutzerdefinierte Kategorie
        public string Description { get; set; }

        // Navigation Property: EF Core erkennt Beziehung
        public Account Account { get; set; }
    }
}
